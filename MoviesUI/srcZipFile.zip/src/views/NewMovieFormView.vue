<template>
  <new-movie-form />
</template>

<script>
import NewMovieForm from '../components/NewMovieForm.vue'

export default {
    name: 'new-movie-form'
}
</script>

<style>

</style>